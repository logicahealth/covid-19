# ig-template-base
package-id = fhir.base.template

Base IG template managed by HL7 but usable by anyone (no logos).  The foundation for most HL7-published IGs
